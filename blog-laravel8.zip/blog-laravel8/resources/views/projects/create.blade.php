@extends("layouts.app")

@section("content")
    <div class="flex justify-center flex-wrap p-4 mt-5">
        @include("projects.form")
    </div>
@endsection
